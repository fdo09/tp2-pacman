package modelo.excepciones;

public class CasasLlenasException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
