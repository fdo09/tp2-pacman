package modelo.excepciones;

public class VelocInvalidaFantasException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VelocInvalidaFantasException() {
		
	}



}
