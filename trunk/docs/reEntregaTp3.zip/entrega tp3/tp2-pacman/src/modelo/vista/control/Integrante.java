package modelo.vista.control;

import ar.uba.fi.algo3.titiritero.Posicionable;

public interface Integrante extends Posicionable {

}
