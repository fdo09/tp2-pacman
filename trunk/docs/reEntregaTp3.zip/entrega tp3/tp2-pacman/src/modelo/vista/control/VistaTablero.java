package modelo.vista.control;

import java.awt.Color;

import ar.uba.fi.algo3.titiritero.vista.Cuadrado;

public class VistaTablero extends Cuadrado{

	public VistaTablero(){
		super(240,240);
		setColor(Color.GREEN);
	}
}
