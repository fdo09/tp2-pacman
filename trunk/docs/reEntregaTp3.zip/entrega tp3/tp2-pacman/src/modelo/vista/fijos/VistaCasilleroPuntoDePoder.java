package modelo.vista.fijos;

import java.awt.Color;

public class VistaCasilleroPuntoDePoder extends VistaCasillero {

	public VistaCasilleroPuntoDePoder() {
		super();
		setColor(Color.BLACK);
		
	}

}
