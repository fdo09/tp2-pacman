package modelo.vista.fijos;

import java.awt.Color;

public class VistaCasilleroPared extends VistaCasillero {

	public VistaCasilleroPared() {
		super();
		setColor(Color.BLUE);
	}

}
