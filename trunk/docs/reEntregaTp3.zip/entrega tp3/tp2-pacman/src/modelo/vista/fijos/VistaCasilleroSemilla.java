package modelo.vista.fijos;

import java.awt.Color;

public class VistaCasilleroSemilla extends VistaCasillero {

	public VistaCasilleroSemilla() {
		super();
		setColor(Color.BLACK);
	}

}
