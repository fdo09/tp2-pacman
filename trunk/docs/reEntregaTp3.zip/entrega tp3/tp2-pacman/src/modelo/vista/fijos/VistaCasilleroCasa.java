package modelo.vista.fijos;

import java.awt.Color;


public class VistaCasilleroCasa extends VistaCasillero {

	public VistaCasilleroCasa() {
		super();
		setColor(Color.CYAN);
	}

}
