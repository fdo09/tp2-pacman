package modelo.vista.fijos;

import java.awt.Color;

import ar.uba.fi.algo3.titiritero.vista.Cuadrado;

public class VistaCasillero extends Cuadrado {
	
	public VistaCasillero(){
		super(25, 25);
		setColor(Color.RED);
		
		
	}

}
