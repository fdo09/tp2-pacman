package modelo.vista.fijos;

import java.awt.Color;

public class VistaCasilleroPremio extends VistaCasillero{
	
	public VistaCasilleroPremio(){
		super();
		super.setColor(Color.BLACK);
	}
}
