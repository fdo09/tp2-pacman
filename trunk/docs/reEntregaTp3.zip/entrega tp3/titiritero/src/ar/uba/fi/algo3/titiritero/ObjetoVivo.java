package ar.uba.fi.algo3.titiritero;

public interface ObjetoVivo {
	
	void vivir();
	
}
